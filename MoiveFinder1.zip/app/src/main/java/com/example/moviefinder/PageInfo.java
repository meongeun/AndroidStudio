package com.example.moviefinder;

public class PageInfo {

    public static final int PAGES = 3;//페이지 수

    //페이지 번호
    public static final int FRAGMENT_PAGE1 = 0;
    public static final int FRAGMENT_PAGE2 = 1;
    public static final int FRAGMENT_PAGE3 = 2;
}
